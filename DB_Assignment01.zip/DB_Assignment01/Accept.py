#Write a program to accept category like "romance" and display list of books of that category.

import pymysql

con = pymysql.connect(host='localhost' , user='root' , password='Lenovo' , database='bookstoredb')
cur=con.cursor()

cat = input("Enter Category: ")

print('Name of Books:')
cur.execute("Select Bookname from book where Category='%s'" %(cat))
data = cur.fetchone()
print(data)

con.close()
