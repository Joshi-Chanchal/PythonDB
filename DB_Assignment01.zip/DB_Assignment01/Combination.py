#Write a program to accept author and publication, display list of books of the author-publication combination.
import pymysql

con=pymysql.connect(host='localhost',user='root',password='Lenovo',database='bookstoredb')
cur=con.cursor()

au=input('Enter author name: ')
pub=input('Enter name of publisher: ')
cur.execute("select Bookname from book Where Author='%s'and Publisher='%s'" %(au,pub))
data=cur.fetchone()
while data:
    print(data)
    data = cur.fetchone()

con.close()