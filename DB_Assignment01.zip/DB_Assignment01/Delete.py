#Write a program to accept bookcode, display the book data and ask "Do you want to delete?" if "yes" delete the book from the table.

import pymysql

con=pymysql.connect(host='localhost',user='root',password='Lenovo',database='bookstoredb')
cur=con.cursor()

try:
    code=int(input('Enter Bookcode to delete: '))
    cur.execute("select * from book where Bookcode=%d" %(code))
    data=cur.fetchone()
    print(data)
    n=input('Do you want to delete(Yes/No)? ')
    if (n.upper()=='YES'):
        cur.execute("delete from book Where Bookcode=%d" %(code))
        con.commit()
        print('Book Data deleted Successfully..')
    else:
        print('Book data does not exist..')
except:
     print('Error in deletion..')
con.close()
