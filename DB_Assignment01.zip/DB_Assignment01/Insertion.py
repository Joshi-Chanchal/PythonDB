#Write a program to take input and add new books to the DB table.

import pymysql

c = pymysql.connect(host='localhost' , user='root' , password='Lenovo' , database='bookstoredb')
cur = c.cursor()
try:
    code = int(input("Enter book code :"))
    name = input("Enter book name : ")
    cat = input("Enter category : ")
    au = input("Enter Author name : ")
    pub = input("Enter Publisher : ")
    price = int(input("Enter price : "))

    cur.execute("insert into book values(%d,'%s','%s','%s','%s',%d)" %(code,name,cat,au,pub,price ))
    c.commit()
    c.close()
    print('Book Entry was Succesfull')
except:
    print('Book Entry Failed...')