#Add new column "review varchar(500)" to the books table using alter query.

import pymysql

con=pymysql.connect(host='localhost',user='root',password='Lenovo',database='bookstoredb')
cur=con.cursor()

#cur.execute("alter table book add review varchar(500)")
#con.commit()
cur.execute("select * from book")
data=cur.fetchone()
while data:
    print(data)
    data=cur.fetchone()
con.close()
