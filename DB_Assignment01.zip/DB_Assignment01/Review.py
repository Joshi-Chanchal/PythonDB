#Write a program to accept bookcode, update the record with the review contents

import pymysql

con=pymysql.connect(host='localhost',user='root',password='Lenovo',database='bookstoredb')
cur=con.cursor()

code=int(input('Enter Bookcode: '))
review=input('Enter Your review : ')

try:
    cur.execute("update book set review='%s' Where Bookcode=%d" %(review,code))
    con.commit()
    print("Updation is Succesfull..")
except:
    print('Updation is fail..')
