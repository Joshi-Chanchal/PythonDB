
#Write a program to accept bookcode, search book in the table, show the book details if found else display "not found" message.
import pymysql

con=pymysql.connect(host='localhost' , user='root' , password='Lenovo' , database='bookstoredb')
cur=con.cursor()

code=int(input("Enter Bookcode: "))
cur.execute("select * from book where Bookcode='%d'" %(code))
data=cur.fetchone()

try:
    print('Name: %s' %data[1])
    print('Category: %s' %data[2])
    print('Author: %s' %data[3])
    print('Publisher: %s' %data[4])
    print('Price: %d'%data[5])
except:
    print("Book does not found..")