#Write a program to show list of all books.
import pymysql

con= pymysql.connect(host='localhost' ,user='root',password='Lenovo',database='bookstoredb')
cur=con.cursor()

cur.execute("select * from book")
data = cur.fetchone()
while data:
    print(data)
    data = cur.fetchone()
con.close()