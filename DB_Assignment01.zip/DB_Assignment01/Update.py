#Write a program to accept bookcode & new price and update book data in the table if found else display "book does not exist".

import pymysql

con = pymysql.connect(host='localhost' , user='root' , password='Lenovo' , database='bookstoredb')
cur=con.cursor()

code = int(input("Enter Bookcode : "))
price = int(input("Enter price : "))

b=input("Enter new Bookname : ")
c=input("Enter new Category : ")
a=input("Enter new Author : ")
p=input("Enter new Publisher : ")
try:
    cur.execute("Update book set Bookname='%s' ,Category='%s', Author='%s' ,Publisher='%s' where Bookcode=%d and Price=%d" %(b,c,a,p,code,price))
    con.commit()
    print("Entery successfull..")
except:
    print("BOOk does not Exist")


